/**
 * @author Andrew Dong
 * @date 2018/12/6 18:05
 */
public class Character {
    private String name;
    private Integer characterId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCharacterId() {
        return characterId;
    }

    public void setCharacterId(Integer characterId) {
        this.characterId = characterId;
    }
}
